using System.ComponentModel.DataAnnotations;

namespace Kollok.Models.Requests;

/// <summary>
/// Данные о сне.
/// </summary>
public class AddSleepRequest
{
    /// <summary>
    /// Длительность сна в минутах.
    /// </summary>
    [Required(ErrorMessage = "Поле Duration является обязательным")]
    [Range(0, 3000, ErrorMessage = "Максимальное допустимое количеcтво=3000")]
    public int? Duration { get; set; } = null!;
}