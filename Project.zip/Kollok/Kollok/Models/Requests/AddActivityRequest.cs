using System.ComponentModel.DataAnnotations;

namespace Kollok.Models.Requests;

/// <summary>
/// Физическая активность.
/// </summary>
public class AddActivityRequest
{
    /// <summary>
    /// Тип активности.
    /// </summary>
    [Required(ErrorMessage = "Поле Type является обязательным")]
    [MaxLength(50, ErrorMessage = "Максимальная длина=50")]
    public string Type { get; set; } = null!;

    /// <summary>
    /// Длительность в минутах.
    /// </summary>
    [Required(ErrorMessage = "Поле Duration является обязательным")]
    [Range(0, 1440, ErrorMessage = "Длительность сна не может быть больше суток")]
    public int? Duration { get; set; } = null!;

    /// <summary>
    /// Количество каллорий.
    /// </summary>
    [Required(ErrorMessage = "Поле Calories является обязательным")]
    [Range(0, 3000, ErrorMessage = "Максимальное допустимое количество=3000")]
    public int? Calories { get; set; } = null!;
}