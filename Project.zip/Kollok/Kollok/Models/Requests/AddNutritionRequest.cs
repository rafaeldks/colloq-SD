using System.ComponentModel.DataAnnotations;

namespace Kollok.Models.Requests;

/// <summary>
/// Данные о приеме пищи.
/// </summary>
public class AddNutritionRequest
{
    /// <summary>
    /// Название блюда.
    /// </summary>
    [Required(ErrorMessage = "Поле Dish является обязательным")]
    [MaxLength(100, ErrorMessage = "Максимальная длина=100")]
    public string Dish { get; set; } = null!;

    /// <summary>
    /// Количество граммов.
    /// </summary>
    [Required(ErrorMessage = "Поле Serving является обязательным")]
    [Range(0, 5000, ErrorMessage = "Максимальное допустимое количество=5000")]
    public int? Serving { get; set; } = null!;

    /// <summary>
    /// Количество каллорий.
    /// </summary>
    [Required(ErrorMessage = "Поле Calories является обязательным")]
    [Range(0, 3000, ErrorMessage = "Максимальное допустимое количество=3000")]
    public int? Calories { get; set; } = null!;
}