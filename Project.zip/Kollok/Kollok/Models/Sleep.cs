using Kollok.Models.Requests;

namespace Kollok.Models;

public class Sleep
{
    public int Duration { get; set; }

    public static Sleep Build(AddSleepRequest request)
    {
        return new Sleep
        {
            Duration = (int)request.Duration
        };
    }
}