using Kollok.Models.Requests;

namespace Kollok.Models;

public class Nutrition
{
    public string Dish { get; set; }
    
    public int Serving { get; set; }
    
    public int Calories { get; set; }

    public static Nutrition Build(AddNutritionRequest request)
    {
        return new Nutrition
        {
            Dish = request.Dish,
            Calories = (int)request.Calories,
            Serving = (int)request.Serving
        };
    }
}