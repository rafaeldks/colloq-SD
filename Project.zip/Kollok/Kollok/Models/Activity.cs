using System.Collections.Immutable;
using Kollok.Models.Requests;

namespace Kollok.Models;

public class Activity
{
    public string Type { get; set; } = null!;
    
    public int Duration { get; set; }
        
    public int Calories { get; set; }

    public static Activity Build(AddActivityRequest request)
    {
        return new Activity
        {
            Calories = (int)request.Calories,
            Duration = (int)request.Duration,
            Type = request.Type
        };
    }
}