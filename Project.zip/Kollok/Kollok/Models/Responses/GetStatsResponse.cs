namespace Kollok.Models.Responses;

/// <summary>
/// Статистика по сну, еде и физической активности.
/// </summary>
public class GetStatsResponse
{
    /// <summary>
    /// Общее количество съеденных каллорий.
    /// </summary>
    public int ReceivedCalories { get; set; }
    
    /// <summary>
    /// Общее количество потраченных каллорий.
    /// </summary>
    public int SpentCalories { get; set; }
    
    /// <summary>
    /// Общая длительность сна в минутах.
    /// </summary>
    public int SleepDuration { get; set; }
    
    /// <summary>
    /// Общая длительность физической активности в минутах.
    /// </summary>
    public int ActivityDuration { get; set; }
}