using Kollok.Models.Requests;
using Kollok.Services.Interfaces;
using Microsoft.AspNetCore.Mvc;

namespace Kollok.Controllers;

[ApiController]
[Route("api/v1/activity")]
public class ActivityController : ControllerBase
{
    private readonly IActivityService _activityService;

    public ActivityController(IActivityService activityService)
    {
        _activityService = activityService;
    }
    
    /// <summary>
    /// Добавляет новую активность.
    /// </summary>
    /// <param name="request"></param>
    /// <returns>Id созданной активности</returns>
    [HttpPost("add")]
    public IActionResult AddActivity(AddActivityRequest request)
    {
        var activityId = _activityService.AddActivity(request);
        return Ok(new { activityId = activityId });
    }
}