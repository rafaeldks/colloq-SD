using Kollok.Models.Requests;
using Kollok.Services.Interfaces;
using Microsoft.AspNetCore.Mvc;

namespace Kollok.Controllers;

[ApiController]
[Route("api/v1/nutrion")]
public class NutritionController : ControllerBase
{
    private readonly INutritionService _nutritionService;

    public NutritionController(INutritionService nutritionService)
    {
        _nutritionService = nutritionService;
    }
    
    /// <summary>
    /// Добавляет новый примем пищи.
    /// </summary>
    /// <param name="request"></param>
    /// <returns>Id созданного приема пищи.</returns>
    [HttpPost("add")]
    public IActionResult AddNutrition(AddNutritionRequest request)
    {
        var nutrionId = _nutritionService.AddNutrionAndGetId(request);
        return Ok(new { nutrionId = nutrionId });
    }
}