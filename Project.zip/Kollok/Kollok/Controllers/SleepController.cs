using Kollok.Models.Requests;
using Kollok.Services.Interfaces;
using Microsoft.AspNetCore.Mvc;

namespace Kollok.Controllers;

[ApiController]
[Route("api/v1/sleep")]
public class SleepController : ControllerBase
{
    private readonly ISleepService _sleepService;

    public SleepController(ISleepService sleepService)
    {
        _sleepService = sleepService;
    }
    
    /// <summary>
    /// Добавляет данные о сне.
    /// </summary>
    /// <param name="request"></param>
    /// <returns>Id нового цикла сна.</returns>
    [HttpPost("add")]
    public IActionResult AddSleep(AddSleepRequest request)
    {
        var sleepId = _sleepService.AddSleepAndGetId(request);
        return Ok(new { sleepId = sleepId });
    }
}