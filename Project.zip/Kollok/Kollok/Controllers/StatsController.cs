using Kollok.Models.Requests;
using Kollok.Services.Interfaces;
using Microsoft.AspNetCore.Mvc;

namespace Kollok.Controllers;

[ApiController]
[Route("api/v1/stats")]
public class StatsController : ControllerBase
{
    private readonly IStatsService _statsService;

    public StatsController(IStatsService statsService)
    {
        _statsService = statsService;
    }
    
    /// <summary>
    /// Получает Стастистику по всем активностям, сне и примемах пищи.
    /// </summary>
    /// <returns></returns>
    [HttpGet]
    public IActionResult GetStats()
    {
        var response = _statsService.GetStats();
        return Ok(response);
    }
}