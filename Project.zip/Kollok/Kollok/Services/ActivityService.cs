using Kollok.Models;
using Kollok.Models.Requests;
using Kollok.Services.Interfaces;

namespace Kollok.Services;

public class ActivityService : IActivityService
{
    private readonly IDbService _dbService;

    public ActivityService(IDbService dbService)
    {
        _dbService = dbService;
    }

    public long AddActivity(AddActivityRequest request)
    {
        var activity = Activity.Build(request);
        var activityId = _dbService.AddActivityAndGetId(activity);
        return activityId;
    }
}