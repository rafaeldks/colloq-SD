using Kollok.Models.Requests;
using Kollok.Services.Interfaces;
using Kollok.Services.PostgresDbService.Models;

namespace Kollok.Services;

public class SleepService : ISleepService
{
    private readonly IDbService _dbService;
    
    public SleepService(IDbService dbService)
    {
        _dbService = dbService;
    }
    public long AddSleepAndGetId(AddSleepRequest request)
    {
        var sleep = Models.Sleep.Build(request);
        var sleepId = _dbService.AddSleepAndGetId(sleep);
        return sleepId;
    }
}