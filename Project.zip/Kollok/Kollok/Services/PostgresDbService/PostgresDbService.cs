using Kollok.Models;
using Kollok.Services.PostgresDbService;
using Kollok.Services.Interfaces;

namespace Kollok.Services.PostgresDbService;

public class PostgresDbService : IDbService
{
    public long AddActivityAndGetId(Activity activity)
    {
        var pgActivity = Models.Activity.Build(activity);
        using (HealthContext db = new HealthContext())
        {
            db.Activities.Add(pgActivity);
            db.SaveChanges();
            return pgActivity.Id;
        }
    }

    public long AddNutritionAndGetId(Nutrition nutrition)
    {
        var pgNutrition = Models.Nutrition.Build(nutrition);
        using (HealthContext db = new HealthContext())
        {
            db.Nutritions.Add(pgNutrition);
            db.SaveChanges();
            return pgNutrition.Id;
        }
    }

    public long AddSleepAndGetId(Sleep sleep)
    {
        Models.Sleep pgSleep = Models.Sleep.Build(sleep);
        using (HealthContext db = new HealthContext())
        {
            db.Sleeps.Add(pgSleep);
            db.SaveChanges();
            return pgSleep.Id;
        }
    }

    public int GetAllRecievedCalories()
    {
        using (HealthContext db = new HealthContext())
        {
            return db.Nutritions.Sum(nutrition => nutrition.Calories);
        }
    }
    
    public int GetAllSpentCalories()
    {
        using (HealthContext db = new HealthContext())
        {
            return db.Activities.Sum(activity => activity.Calories);
        }
    }
    
    public int GetAllSleepDuration()
    {
        using (HealthContext db = new HealthContext())
        {
            return db.Sleeps.Sum(sleep => sleep.Duration);
        }
    }
    
    public int GetAllActivityDuration()
    {
        using (HealthContext db = new HealthContext())
        {
            return db.Activities.Sum(activity => activity.Duration);
        }
    }
}