﻿using System;
using System.Collections.Generic;

namespace Kollok.Services.PostgresDbService.Models
{
    public partial class Nutrition
    {
        public long Id { get; set; }
        public string Dish { get; set; } = null!;
        public int Serving { get; set; }
        public int Calories { get; set; }

        public static Nutrition Build(Kollok.Models.Nutrition nutrition)
        {
            return new Nutrition
            {
                Calories = (int)nutrition.Calories,
                Dish = nutrition.Dish,
                Serving = (int)nutrition.Serving
            };
        }
    }
}
