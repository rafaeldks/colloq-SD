﻿using System;
using System.Collections.Generic;
using System.Collections.Immutable;

namespace Kollok.Services.PostgresDbService.Models
{
    public partial class Sleep
    {
        public long Id { get; set; }
        public int Duration { get; set; }

        public static Sleep Build(Kollok.Models.Sleep sleep)
        {
            return new Sleep
            {
                Duration = (int)sleep.Duration,
            };
        }
    }
}
