﻿using System;
using System.Collections.Generic;

namespace Kollok.Services.PostgresDbService.Models
{
    public partial class Activity
    {
        public long Id { get; set; }
        public string Type { get; set; } = null!;
        public int Duration { get; set; }
        
        public int Calories { get; set; }

        public static Activity Build(Kollok.Models.Activity activity)
        {
            return new Activity
            {
                Calories = (int)activity.Calories,
                Duration = (int)activity.Duration,
                Type = activity.Type
            };
        }
    }
}
