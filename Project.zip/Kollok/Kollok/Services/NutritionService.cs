using Kollok.Models.Requests;
using Kollok.Services.Interfaces;

namespace Kollok.Services;

public class NutritionService : INutritionService
{
    private readonly IDbService _dbService;

    public NutritionService(IDbService dbService)
    {
        _dbService = dbService;
    }
    public long AddNutrionAndGetId(AddNutritionRequest request)
    {
        var nutrition = Models.Nutrition.Build(request);
        var nutritionId = _dbService.AddNutritionAndGetId(nutrition);
        return nutritionId;
    }
}