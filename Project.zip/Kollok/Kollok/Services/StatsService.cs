using Kollok.Models.Responses;
using Kollok.Services.Interfaces;

namespace Kollok.Services;

public class StatsService : IStatsService
{
    private readonly IDbService _dbService;

    public StatsService(IDbService dbService)
    {
        _dbService = dbService;
    }
    public GetStatsResponse GetStats()
    {
        var receivedCalories = _dbService.GetAllRecievedCalories();
        var spentCalories = _dbService.GetAllSpentCalories();
        var sleepDuration = _dbService.GetAllSleepDuration();
        var activityDuration = _dbService.GetAllActivityDuration();
        return new GetStatsResponse
        {
            ReceivedCalories = receivedCalories,
            SpentCalories = spentCalories,
            SleepDuration = sleepDuration,
            ActivityDuration = activityDuration
        };
    }
}