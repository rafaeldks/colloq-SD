using Kollok.Models.Requests;

namespace Kollok.Services.Interfaces;

public interface IActivityService
{
    public long AddActivity(AddActivityRequest request);
}