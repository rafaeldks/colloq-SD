using Kollok.Models.Requests;

namespace Kollok.Services.Interfaces;

public interface INutritionService
{
    public long AddNutrionAndGetId(AddNutritionRequest request);
}