using Kollok.Models.Requests;

namespace Kollok.Services.Interfaces;

public interface ISleepService
{
    public long AddSleepAndGetId(AddSleepRequest request);
}