using Kollok.Models.Responses;

namespace Kollok.Services.Interfaces;

public interface IStatsService
{
    GetStatsResponse GetStats();
}