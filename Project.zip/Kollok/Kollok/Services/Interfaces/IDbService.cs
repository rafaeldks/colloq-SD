using Kollok.Models;

namespace Kollok.Services.Interfaces;

public interface IDbService
{
    public long AddActivityAndGetId(Activity activity);

    public long AddNutritionAndGetId(Nutrition nutrition);

    public long AddSleepAndGetId(Sleep sleep);

    public int GetAllRecievedCalories();

    public int GetAllSpentCalories();

    public int GetAllSleepDuration();

    public int GetAllActivityDuration();
}